#pragma once
namespace toolStruct {
    struct QuestInfo
    {
        int* QuestId;
        int* QuestState;
    };
    struct ActionFrame
    {
        float* frame;
        float* frameEnd;
        float* frameSpeedRate;
    };
    struct PlayerWeaponInfo
    {
        int type;
        int id;
        int* sharpness;
    };

    struct coordinate
    {
        float x;
        float y;
        float z;
    };

    /// <summary>
    /// ��ͼid�͵�������id
    /// </summary>
    struct WorldInfo {
        int mapId;
        coordinate wayPointCoordinate;
        
    };
    enum MutekiState
    {
        Normal = 1,
        Escape = 3,
        Hyper = 10,
    };
    enum PlayerWeaponType
    {
        GreatSword = 0,
        SwordShield = 1,
        DualBlades = 2,
        LongSword = 3,
        Hammer = 4,
        HuntingHorn = 5,
        Lance = 6,
        Gunlance = 7,
        SwitchAxe = 8,
        ChargeBlade = 9,
        InsectGlaive = 10,
        Bow = 11,
        HeavyBowGun = 12,
        LightBowGun = 13,
    };
}