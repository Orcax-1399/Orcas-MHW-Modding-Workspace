﻿// dllmain.cpp : Définit le point d'entrée de l'application DLL.
// MHWDLLMod 005
#include <fstream>
#include <queue>
#include <functional>

#include <random>
#include <iostream>
#include <cmath>

#include <windows.h>

#include "minhook/MinHook.h"
#include "json/json.hpp"
#include "loader.h"
#include "ghidra_export.h"
#include "util.h"
#include <thread>

#include "Base.h"
#include "Component.h"
#include "ControlProgram.h"
#define _USE_MATH_DEFINES
#include <string>
#include <conio.h>
#include <math.h>
#include "AOB memscan.h"
#include <MMSystem.h>
#pragma comment(lib,"Winmm.lib")

#pragma warning(disable:4996)

using namespace std;
using namespace loader;
using namespace nlohmann;
using json = nlohmann::json;

json config = json::object();


static void* (*kairen)(void*) = (void* (*)(void*))0x142121190;
//static void* (*effects)(void*, int, int) = (void* (*)(void*, int, int))0x140B01880;

void showMessage(std::string message) {
	MH::Chat::ShowGameMessage(*(undefined**)MH::Chat::MainPtr, (undefined*)&message[0], -1, -1, 0);
}

struct keyboardkeys
{
	int keyset_Y = VK_LBUTTON;
	int keyset_B = VK_RBUTTON;
	int keyset_A = VK_SPACE;
	int keyset_RT = VK_XBUTTON2;
	int keyset_RB = VK_LSHIFT;
	int keyset_LT = 67;
	float Y = 0;
	float B = 0;
	float A = 0;
	float RT = 0;
	float RB = 0;
	float LT = 0;
} Keys;

void init_json() {
	int Y = config.value<int>("Y", VK_LBUTTON);
	int A = config.value<int>("A", VK_SPACE);
	int B = config.value<int>("B", VK_RBUTTON);
	int RT = config.value<int>("RT", VK_XBUTTON2);
	int RB = config.value<int>("RB", VK_LSHIFT);
	int LT = config.value<int>("LT", 67);
	Keys.keyset_Y = Y;
	Keys.keyset_A = A;
	Keys.keyset_B = B;
	Keys.keyset_RT = RT;
	Keys.keyset_RB = RB;
	Keys.keyset_LT = LT;
}

bool dirExists(const std::string& dirName_in) {
	DWORD ftyp = GetFileAttributesA(dirName_in.c_str());
	if (ftyp == INVALID_FILE_ATTRIBUTES)
		return false; //something is wrong with your path!
	if (ftyp & FILE_ATTRIBUTE_DIRECTORY)
		return true;
	return false;
}

void load_json() {
	config["Y"] = VK_LBUTTON;
	config["A"] = VK_SPACE;
	config["B"] = VK_RBUTTON;
	config["RT"] = VK_XBUTTON2;
	config["RB"] = VK_LSHIFT;
	config["LT"] = 67;
RESTART:
	ifstream i(".\\nativePC\\plugins\\iai\\key_config.json");
	if (!i.is_open() || i.eof()) {
		if (!dirExists(".\\nativePC\\plugins\\iai"))
			CreateDirectory(".\\nativePC\\plugins\\iai", NULL);
		ofstream myfile(".\\nativePC\\plugins\\iai\\key_config.json", fstream::out);
		//myfile << "{\n\"Y\":1,\n\"B\":2,\n\"A\":32,\n\"RT\":6,\n\"RB\":160,\n\"LT\":67\n}";
		myfile << config;
		myfile.close();
		goto RESTART;
	}
	if (!i.fail())
	{
		config.clear();
		i >> config;
		i.close();
	}
	else { LOG(ERR) << "iai: load key_config.json failed!"; return; }

	init_json();
	return;
}

//简单获取键盘按键
void GetNowKey()
{
	JOYINFO joyinfo;
	JOYINFOEX joyinfoex;
	joyinfoex.dwSize = sizeof(JOYINFOEX);
	joyinfoex.dwFlags = JOY_RETURNALL;

	for (;;) {

		UINT joy_nums;
		joy_nums = joyGetNumDevs();
		if (joy_nums > 0) {
			MMRESULT joy_ret = joyGetPosEx(JOYSTICKID1, &joyinfoex);
			if (joy_ret == JOYERR_NOERROR) {
				if (joyinfoex.dwButtons == 1)
					Keys.A = Keys.A + 0.0166;

				if (joyinfoex.dwButtons == 2)
					Keys.B = Keys.B + 0.0166;

				if (joyinfoex.dwButtons == 8)
					Keys.Y = Keys.Y + 0.0166;

				if (joyinfoex.dwButtons == 32)
					Keys.RB = Keys.RB + 0.0166;

				if (joyinfoex.dwZpos < 32767)
					Keys.RT = Keys.RT + 0.0166;

				if (joyinfoex.dwZpos > 32767)
					Keys.LT = Keys.LT + 0.0166;
			}
		}
		if (GetAsyncKeyState(Keys.keyset_Y) < 0)
			Keys.Y = Keys.Y + 0.0166;

		if (GetAsyncKeyState(Keys.keyset_B) < 0)
			Keys.B = Keys.B + 0.0166;

		if (GetAsyncKeyState(Keys.keyset_A) < 0)
			Keys.A = Keys.A + 0.0166;

		if (GetAsyncKeyState(Keys.keyset_LT) < 0)
			Keys.LT = Keys.LT + 0.0166;

		if (GetAsyncKeyState(Keys.keyset_RB) < 0)
			Keys.RB = Keys.RB + 0.0166;

		if (GetAsyncKeyState(Keys.keyset_RT) < 0)
			Keys.RT = Keys.RT + 0.0166;

		if (joyinfoex.dwButtons == 0 && GetAsyncKeyState(Keys.keyset_Y) == 0)
			Keys.Y = 0;

		if (joyinfoex.dwButtons == 0 && GetAsyncKeyState(Keys.keyset_B) == 0)
			Keys.B = 0;

		if (joyinfoex.dwButtons == 0 && GetAsyncKeyState(Keys.keyset_A) == 0)
			Keys.A = 0;

		if (joyinfoex.dwButtons == 0 && GetAsyncKeyState(Keys.keyset_RB) == 0)
			Keys.RB = 0;

		if (joyinfoex.dwZpos == 32767 && GetAsyncKeyState(Keys.keyset_RT) == 0)
			Keys.RT = 0;

		if (joyinfoex.dwZpos == 32767 && GetAsyncKeyState(Keys.keyset_LT) == 0)
			Keys.LT = 0;

		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}
	//return;
}

//删除大居合掉刃，让普通攻击也有刀光.	
void asm_edit() {
	Sleep(10000);
	DWORD pid;
	HWND hwnd = FindWindow(NULL, "MONSTER HUNTER: WORLD(421631)");
	GetWindowThreadProcessId(hwnd, &pid);
	HANDLE hprocess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	DWORD64 readByte = NULL;

	char ASM_iai_not_decrease_blade_lv[] = { 0xEB };

	WriteProcessMemory(hprocess, (LPVOID)0X142121B80, ASM_iai_not_decrease_blade_lv, sizeof(ASM_iai_not_decrease_blade_lv), NULL);

	char not_cleat_gauge[] = { 0x90,0x90,0x90,0x90,0x90,0x90 };

	WriteProcessMemory(hprocess, (LPVOID)0x1421211bb, not_cleat_gauge, sizeof(not_cleat_gauge), NULL);

	char blade_efx[] = { 0X0F, 0X99, 0XC3 };

	WriteProcessMemory(hprocess, (LPVOID)0x14212283B, blade_efx, sizeof(blade_efx), NULL);

	return;
}

void fsm_derive(int input1, int input2) {
	void* CoordinatesPlot = *(undefined**)MH::Player::PlayerBasePlot;
	void* CoordinatesPlot1 = *offsetPtr<void*>(CoordinatesPlot, 0x50);
	*offsetPtr<int>(CoordinatesPlot1, 0x6284) = input1;
	*offsetPtr<int>(CoordinatesPlot1, 0x6288) = input2;
	return;
}

void mian_loop() {
	//等待十秒钟避免空指针
	Sleep(10000);

	//手柄输入基址
	//void* key = *((undefined**)0x145224a98);

	//玩家基址
	void* CoordinatesPlot = *(undefined**)MH::Player::PlayerBasePlot;

	//输入缓存
	int input[2] = { 0,0 };

	//居合成功标记位
	bool iai_suc = false;

	while (1) {
		//线程每秒运行60次,模拟60帧刷新
		//Sleep(16);
		std::this_thread::sleep_for(std::chrono::milliseconds(16));

		//获取键盘按键
		//GetNowKey();

		//获取基址,若为空指针则重新开始循环,避免访问到非法地址
		if (CoordinatesPlot == nullptr) continue;
		void* CoordinatesPlot1 = *offsetPtr<void*>(CoordinatesPlot, 0x50);
		if (CoordinatesPlot1 == nullptr) continue;
		void* EFX = *offsetPtr<void*>(CoordinatesPlot1, 0x8808);
		if (EFX == nullptr) continue;
		void* playeroff = *offsetPtr<void*>(CoordinatesPlot1, 0x76B0);
		if (playeroff == nullptr) continue;
		void* healthoff = *offsetPtr<void*>(CoordinatesPlot1, 0x7630);
		if (healthoff == nullptr) continue;
		void* wepoff = *offsetPtr<void*>(CoordinatesPlot1, 0xc0);
		if (wepoff == nullptr) continue;
		void* actoff = *offsetPtr<void*>(CoordinatesPlot1, 0x468);
		if (actoff == nullptr) continue;
		wepoff = *offsetPtr<void*>(wepoff, 0x8);
		wepoff = *offsetPtr<void*>(wepoff, 0x78);

		//血量大于0.1 同时武器为太刀才生效
		if (*offsetPtr<float>(healthoff, 0x64) > 0.1f && *offsetPtr<int>(wepoff, 0x2e8) == 0x3) {

			//翔虫受身,消耗一层气刃槽
			if (*offsetPtr<int>(actoff, 0xe9c4) >= 4000 && *offsetPtr<int>(actoff, 0xe9c4) <= 5000 && *offsetPtr<int>(playeroff, 0x2370) > 0) {
				if (Keys.LT > 0 && Keys.A > 0) {
					//派生绝对回避
					fsm_derive(1, 0x26a);
					//特效 叮
					//effects(EFX, 2004, 0);
					//清除气刃槽持续时间来达成掉一层刃
					*offsetPtr<float>(playeroff, 0x2374) = 0.0f;
					*offsetPtr<float>(playeroff, 0x2390) = 0.0f;
				}
			}

			if (*offsetPtr<int>(actoff, 0xe9c4) == 0xC132) {
				if (*offsetPtr<float>(actoff, 0x10c) >= 100.0f) {
					if (Keys.A > 0) {
						//可以用翻滚取消纳刀
						fsm_derive(1, 0x35);
					}
				}
				if (*offsetPtr<float>(actoff, 0x10c) >= 80.0f) {
					if (Keys.RT > 0.0) {
						//按下RT瞬间就居合出手(修复游戏本身居合带有5帧延迟的问题)
						fsm_derive(3, 0x66);
					}
				}
			}

			//大居合派生控制
			if (*offsetPtr<int>(actoff, 0xe9c4) >= 49460 && *offsetPtr<int>(actoff, 0xe9c4) <= 49463) {
				//在居合帧数超过60帧就开始记录输入
				//通过输入缓冲来达成预输入的效果
				if (*offsetPtr<float>(actoff, 0x10c) >= 60.0f) {
					if (input[0] == 0 && input[1] == 0) {
						{
							//大居合成功派生
							if (iai_suc) {
								//若RT被按下,进入循环
								if (Keys.RT > 0.0) {
									for (int RT_count = 0; RT_count < 6; RT_count++) {
										//循环中若A被按下,则认为按下的是RT+A组合键,将纳刀存入缓冲
										if (Keys.A > 0) {
											input[0] = 3;
											input[1] = 0x62;
											break;
										}
										//每个循环有一帧延迟
										std::this_thread::sleep_for(std::chrono::milliseconds(16));

										//若循环5次也没有按下其他组合键,则认为按下的是RT,将气刃斩3存入缓冲
										//本组合键判定方式类似游戏本身,会造成RT有5帧延迟
										if (RT_count == 5 && *offsetPtr<float>(playeroff, 0x2368) >= 0.2f) {
											input[0] = 3;
											input[1] = 0x44;
										}
									}
								}
							}

							//不需要居合成功的派生
							//若按下RB,则将快速纳刀存入缓冲
							if (Keys.RB > 0) {
								input[0] = 3;
								input[1] = 9;
							}
						}
					}
				}

				//若缓冲已有招式,并且帧数大于70帧,则派生缓冲中的招式,并清理缓冲
				//本方式可以在60帧以后开始接受输入数据,并在70帧以后进行派生,类似游戏本身的预输入方式
				if (*offsetPtr<float>(actoff, 0x10c) >= 70.0f) {
					if (input[0] != 0 && input[1] != 0) {
						fsm_derive(input[0], input[1]);
						input[0] = 0; input[1] = 0;
					}
				}
			}
			//清理缓冲
			else { input[0] = 0; input[1] = 0; }

			//大居合的伤害控制
			//-1 = 无伤害,0xE=三层气刃大居合,0xD=二层,0xC=一层,这里本可以区分,但我懒得区分
			if (!iai_suc && *offsetPtr<int>(actoff, 0xe9c4) >= 49460 && *offsetPtr<int>(actoff, 0xe9c4) <= 49463 && *offsetPtr<int>(playeroff, 0x2d24) != 0xFFFFFFFF) {
				*offsetPtr<int>(playeroff, 0x2d24) = 0xFFFFFFFF;
			}
			if (iai_suc)*offsetPtr<int>(playeroff, 0x2d24) = 0xe;

			//大居合开刃
			if (*offsetPtr<BYTE>(playeroff, 0x2CED) == 1 && *offsetPtr<int>(actoff, 0xe9c4) >= 49460 && *offsetPtr<int>(actoff, 0xe9c4) <= 49463) {
				if (*offsetPtr<float>(playeroff, 0x2d10) != 0) {
					*offsetPtr<int>(playeroff, 0x2cec) = 1;
					kairen(playeroff);
				}
			}

			//大居合的成功标志位判定
			if (iai_suc == false && *offsetPtr<BYTE>(playeroff, 0x2CED) == 1 && *offsetPtr<int>(actoff, 0xe9c4) >= 49460 && *offsetPtr<int>(actoff, 0xe9c4) <= 49463)
				iai_suc = true;
			else if (iai_suc == true && *offsetPtr<BYTE>(playeroff, 0x2CED) == 0 && (*offsetPtr<int>(actoff, 0xe9c4) < 49460 || *offsetPtr<int>(actoff, 0xe9c4) > 49463))
				iai_suc = false;
		}
	}
}

__declspec(dllexport) extern bool Load()
{
	load_json();
	thread th1(asm_edit);
	th1.detach();
	thread th2(mian_loop);
	th2.detach();
	thread th3(GetNowKey);
	th3.detach();
	return true;
}


BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
		return Load();

	return TRUE;
}


